//  ContentView.swift
//  vibecheckphotoapp
//
//  Created by Dheeraj on 05/01/26.

import CoreML
import PhotosUI
import SwiftUI
import Vision
import ImageIO

struct ContentView: View {
    @State private var selectedImages: [UIImage] = [] // Store UIImages
    @State private var selectedItems: [PhotosPickerItem] = [] // Selected photo items

    @Environment(\.dismiss) private var dismiss

    @State private var cool: [UIImage] = []
    @State private var notCool: [UIImage] = []

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                Text(Date.now, style: .date)
                    .font(.largeTitle)

                PhotosPicker(selection: $selectedItems,
                             matching: .images) {
                    Text("Select Multiple Photos")
                        .font(.title)
                }
                .padding()
                .onChange(of: selectedItems) { newItems in
                    // Clear old images before loading new ones
                    selectedImages.removeAll()

                    // Load each selected item as Data and convert to UIImage
                    Task {
                        for item in newItems {
                            if let data = try? await item.loadTransferable(type: Data.self),
                               let uiImage = UIImage(data: data) {
                                await MainActor.run {
                                    selectedImages.append(uiImage)
                                }
                            }
                        }
                    }
                }

                VStack(alignment: .leading, spacing: 4) {
                    Text("Selected Photos:")
                        .font(.headline)
                    Text("\(selectedImages.count) total")
                        .font(.subheadline)
                }

                ScrollView(.horizontal) {
                    HStack(spacing: 12) {
                        // Use indices as stable IDs because UIImage is not Hashable
                        ForEach(Array(selectedImages.enumerated()), id: \.offset) { _, image in
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 120, height: 120)
                                .clipped()
                                .cornerRadius(8)
                        }
                    }
                    .padding(.horizontal)
                }
            }
            .navigationTitle("Vibe Check Photo App")
            .padding()
        }
    }

    // Placeholder until a Core ML model is added to the project.
    func coolPhotoChecker() {
        // TODO: Integrate Core ML model here when available.
    }
}

#Preview {
    ContentView()
}
